﻿using UnityEngine;

public static class Steering
{
    // SEEK: Hedefe doğru hareket eden yapay zeka yönlendirme fonksiyonu
    public static Vector2 Seek(Rigidbody2D seeker, Vector2 target, float moveSpeed, float turnSpeed)
    {
        // Mevcut hız ve istenen hızı hesapla
        Vector2 currentVelocity = seeker.linearVelocity;
        Vector2 desiredVelocity = (target - seeker.position).normalized * moveSpeed;
        Vector2 seekForce = desiredVelocity - currentVelocity;

        // Nesneyi hızının yönüne döndür (mouse yerine hız yönüne bakacak)
        float targetAngle = Mathf.Atan2(desiredVelocity.y, desiredVelocity.x) * Mathf.Rad2Deg;
        seeker.MoveRotation(Mathf.MoveTowardsAngle(seeker.rotation, targetAngle, turnSpeed * Time.deltaTime));

        return seekForce;
    }

    // AVOIDANCE: Engelleri algılayıp kaçınma kuvveti uygulayan fonksiyon
    public static Vector2 Avoidance(Rigidbody2D seeker, float rayLength)
    {
        Vector2 avoidanceForce = Vector2.zero;
        Vector2 position = seeker.position;
        Vector2 direction = seeker.linearVelocity.normalized;

        // 4 yönlü ışınlarla engelleri algıla
        float[] angles = { 20f, -20f, 45f, -45f }; // Sol, Sağ, Sol-İleri, Sağ-İleri
        Color[] debugColors = { Color.blue, Color.magenta, Color.green, Color.yellow };

        for (int i = 0; i < angles.Length; i++)
        {
            Vector2 rayDirection = Quaternion.Euler(0, 0, angles[i]) * direction;
            RaycastHit2D hit = Physics2D.Raycast(position, rayDirection, rayLength);

            Debug.DrawLine(position, position + rayDirection * rayLength, debugColors[i]);

            if (hit.collider != null)
            {
                // Çarptığımız engelin normalini kullanarak kaçınma kuvveti oluştur
                Debug.Log("Engel algılandı: " + hit.collider.name);
                avoidanceForce += (Vector2)hit.normal * rayLength;
            }
        }

        return avoidanceForce;
    }
}


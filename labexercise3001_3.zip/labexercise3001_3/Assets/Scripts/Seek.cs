﻿using UnityEngine;

public class Seek : MonoBehaviour
{
    public float moveSpeed = 10.0f;
    public float turnSpeed = 720.0f;
    public float rayLength = 5.0f;
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Fare pozisyonunu dünya koordinatlarına çevir
        Vector3 mouse = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouse.z = 0.0f;

        // Seek ve Avoidance kuvvetlerini hesapla
        Vector2 seekForce = Steering.Seek(rb, mouse, moveSpeed, turnSpeed);
        Vector2 avoidanceForce = Steering.Avoidance(rb, rayLength);

        // Seek ve Avoidance kuvvetlerini birleştirerek uygula
        rb.AddForce(seekForce + avoidanceForce);
    }
}
﻿using UnityEngine;

public static class Steering
{
    // Static Seek method
    public static Vector2 Seek(Rigidbody2D seeker, Vector2 targetPosition, float moveSpeed, float turnSpeed)
    {
        // Calculate the desired direction
        Vector2 currentPosition = seeker.position;
        Vector2 direction = (targetPosition - currentPosition).normalized;

        // Calculate the desired velocity
        Vector2 desiredVelocity = direction * moveSpeed;

        // Calculate the steering force (difference between desired velocity and current velocity)
        Vector2 steeringForce = desiredVelocity - seeker.velocity;

        // Apply the steering force to the Rigidbody2D
        seeker.AddForce(steeringForce);

        // Rotate the seeker to face the direction of movement
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90f; // Adjust for Unity's rotation system
        float smoothedAngle = Mathf.LerpAngle(seeker.rotation, angle, turnSpeed * Time.fixedDeltaTime);
        seeker.MoveRotation(smoothedAngle);

        // Return the calculated steering force (useful for debugging)
        return steeringForce;
    }
}


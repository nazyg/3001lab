﻿using UnityEngine;

public class Seek : MonoBehaviour
{
    public GameObject target; // Hedef GameObject
    public float moveSpeed = 10.0f; // Hareket hızı
    public float turnSpeed = 5.0f; // Dönüş hızı
    private Rigidbody2D rb; // Rigidbody2D referansı

    void Start()
    {
        // Rigidbody2D bileşenini alıyoruz
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        if (target != null)
        {
            // Steering.Seek metodunu çağırarak hareketi uygula
            Steering.Seek(rb, target.transform.position, moveSpeed, turnSpeed);
        }
    }
}
